package com.HIT.StoreManagementApp.repository;

import com.HIT.StoreManagementApp.model.Branch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BranchRepository extends JpaRepository<Branch, Long> {
}
