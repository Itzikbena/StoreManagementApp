package com.HIT.StoreManagementApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
